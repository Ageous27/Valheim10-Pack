# NoAutoPickup

Client-side Valheim mod. Turns auto-pickup **off** near campfires, hearths, tamed animals, and Item Drawers so tossed items stay on the ground (drawers can vacuum them, tames can eat). Walking out of range restores auto-pickup to whatever it was before.

The vanilla AutoPickup hotkey (default **V**, or the controller JoyAutoPickup combo) can turn it back on while you are still in a zone. When the mod changes the flag, it shows the same `AutoPickup: On` / `AutoPickup: Off` HUD message as the game.

## Why

In co-op, people dump loot for Item Drawers to swallow. With auto-pickup on, the nearest player becomes the vacuum instead. Same problem when you toss food for a tame and walk back.

## Range

Uses the **largest** of:

- Valheim default auto-pickup range (2)
- Live `Player.m_autoPickupRange` (BiggerPickupRadius and similar)
- Item Drawers `DrawerPickupRange` from `kg.ItemDrawers.cfg`

On the current pack that is typically **20 m** because drawers are set to 20.

## Install

Client only. Requires [BepInExPack Valheim](https://thunderstore.io/c/valheim/p/denikson/BepInExPack_Valheim/). Does nothing useful on a dedicated server.

Install with a Thunderstore mod manager, or drop `NoAutoPickup.dll` into `BepInEx/plugins` (a subfolder is fine).

## Config

Generated at `BepInEx/config/Ageous.NoAutoPickup.cfg` after first launch.

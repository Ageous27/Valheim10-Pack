@echo off
title Valheim10 ApplyPatches
if not defined APPLYPATCHES_KEEPOPEN (
  set "APPLYPATCHES_KEEPOPEN=1"
  cmd /k "%~f0" %*
  exit /b
)

setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"

set "SRC=%~dp0patched-plugins"
set "TMM=%APPDATA%\Thunderstore Mod Manager\DataFolder\Valheim\profiles"
set "PROFILE=%~1"
if "%PROFILE%"=="" set "PROFILE=Valheim10-Pack"
set "DST=%TMM%\%PROFILE%\BepInEx\plugins"
set "FAIL=0"

echo.
echo Valheim 1.0.12 ApplyPatches
echo.

if not exist "%SRC%\" (
  echo Could not find patched-plugins next to this script:
  echo   %SRC%
  goto :hold
)

if not exist "%DST%\" (
  echo Could not find profile "%PROFILE%" at:
  echo   %DST%
  echo.
  if exist "%TMM%\" (
    echo Profiles on this PC:
    dir /b /ad "%TMM%"
    echo.
  )
  echo Import Valheim10-Pack.r2z in Thunderstore Mod Manager first.
  echo If you renamed the profile, run: ApplyPatches.cmd "YourProfileName"
  goto :hold
)

echo Source:  %SRC%
echo Profile: %DST%
echo.

call :copyone Azumatt-AzuExtendedPlayerInventory AzuExtendedPlayerInventory.dll 1126912
call :copyone Azumatt-Recycle_N_Reclaim Recycle_N_Reclaim.dll 674816
call :copyone blacks7ar-Hunting Hunting.dll 99840
call :copyone Firehunter1980-ItemDrawers_QuickFix_Unofficial kg_ItemDrawers.dll 916992
call :copyone Advize-PlantEverything Advize_PlantEverything.dll 258560
call :copyone korCaptain-PotalMap ServerSync.dll 49664
call :copytree Ageous27-NoAutoPickup NoAutoPickup.dll 17408
call :copytree "Grass Tweaks-306-0-4-0-1692795491" GrassTweaks.dll 8704
call :copyroot Valheim.DisplayBepInExInfo.dll 8704

echo.
if not "!FAIL!"=="0" (
  echo Copy failed. Missing files or wrong sizes are listed above.
  echo Re-import the r2z, then run this script again.
  goto :hold
)

echo Success. Patched plugins are in place, including AzuEPI 2.4.13 and Recycle 1.4.4.
echo Then Play.
goto :hold

:copyone
set "FROM=%SRC%\%~1\%~2"
set "TODIR=%DST%\%~1"
set "TO=%TODIR%\%~2"
if not exist "%FROM%" (
  echo MISSING PATCH  %~1\%~2
  set "FAIL=1"
  goto :eof
)
if not exist "%TODIR%\" (
  echo MISSING FOLDER %~1
  echo Import the r2z and wait for TMM to finish downloading first.
  set "FAIL=1"
  goto :eof
)
copy /Y "%FROM%" "%TO%" >nul
if errorlevel 1 (
  echo COPY FAILED    %~1\%~2
  set "FAIL=1"
  goto :eof
)
for %%I in ("%TO%") do set "SIZE=%%~zI"
if not "!SIZE!"=="%~3" (
  echo WRONG SIZE     %~1\%~2  got !SIZE!  expected %~3
  set "FAIL=1"
  goto :eof
)
echo copied          %~1\%~2  !SIZE! bytes
goto :eof

:copytree
set "FROMDIR=%SRC%\%~1"
set "TODIR=%DST%\%~1"
set "TO=%TODIR%\%~2"
if not exist "%FROMDIR%\" (
  echo MISSING PATCH  %~1
  set "FAIL=1"
  goto :eof
)
if not exist "%TODIR%\" mkdir "%TODIR%" >nul
xcopy /E /Y /Q "%FROMDIR%" "%TODIR%\" >nul
if errorlevel 1 (
  echo COPY FAILED    %~1
  set "FAIL=1"
  goto :eof
)
for %%I in ("%TO%") do set "SIZE=%%~zI"
if not "!SIZE!"=="%~3" (
  echo WRONG SIZE     %~1\%~2  got !SIZE!  expected %~3
  set "FAIL=1"
  goto :eof
)
echo copied          %~1  !SIZE! bytes
goto :eof

:copyroot
set "FROM=%SRC%\%~1"
set "TO=%DST%\%~1"
if not exist "%FROM%" (
  echo MISSING PATCH  %~1
  set "FAIL=1"
  goto :eof
)
copy /Y "%FROM%" "%TO%" >nul
if errorlevel 1 (
  echo COPY FAILED    %~1
  set "FAIL=1"
  goto :eof
)
for %%I in ("%TO%") do set "SIZE=%%~zI"
if not "!SIZE!"=="%~2" (
  echo WRONG SIZE     %~1  got !SIZE!  expected %~2
  set "FAIL=1"
  goto :eof
)
echo copied          %~1  !SIZE! bytes
goto :eof

:hold
echo.
echo Window will stay open. Type exit when you are done.
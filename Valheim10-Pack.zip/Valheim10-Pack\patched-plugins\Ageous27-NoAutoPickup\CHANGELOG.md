# Changelog

## 0.1.2
- Auto-pickup is only forced off when you **enter** a fire / tame / drawer zone. The default game bind (V, or whatever AutoPickup is mapped to) can turn it back on while you stay there.
- When the mod itself flips the flag, it shows the vanilla `AutoPickup: On` / `AutoPickup: Off` HUD message (`$hud_autopickup:`).

## 0.1.1
- Access `Player.m_enableAutoPickup` through Harmony FieldRef so Unity no longer throws `FieldAccessException` every AutoPickup tick.
- Skip vanilla `Player.AutoPickup` while you are inside an exclusion zone. Manual E pickup is unchanged.

## 0.1.0
- Initial client auto-pickup guard for Valheim 1.0.
- Turns auto-pickup off near campfires, hearths, tamed animals, and kg Item Drawers, then restores the previous setting when you walk away.
- Exclusion range is the largest of vanilla 2 m, live `Player.m_autoPickupRange`, and Item Drawers `DrawerPickupRange`.
